package GaussRecursivo;

public class GaussRecursivo {
	public int MetodoRecursivo(int NR) {
		if (NR == 1) return 1;
		else return NR + MetodoRecursivo(NR - 1);
	}
	
	public int MetodoComun(int NC) {
		int Suma=0;
			for (int i=1 ; i<=NC ; i++) Suma+=i;
		return Suma;
	}

	public static void main(String [] args) {
		GaussRecursivo GR = new GaussRecursivo();
			System.out.println("Metodo Recursivo:\n");
				for (int i=1 ; i<=10 ; i++) System.out.println(GR.MetodoRecursivo(i));
			System.out.println("\nMetodo Comun:\n");
				for (int i=1 ; i<=10 ; i++) System.out.println(GR.MetodoComun(i));		
		
		System.out.println("\nMetodo Simple:\n");		
			int Suma=0;
				for (int i=1 ; i<=10 ; i++) { Suma+=i; System.out.println(Suma); }
	}
}